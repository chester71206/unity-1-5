# 🌺 Flower
**Flower** : a KrKr-like dialog system for Unity.

- Github page : [https://github.com/emptygamer/flower](https://github.com/emptygamer/flower)
- Version : 2.0

For more detail about licenses and documents, please check the github page.
